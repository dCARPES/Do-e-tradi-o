
import React from 'react';
import { X, Globe, Bell, Shield, Moon } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose}></div>
      <div className="glass-panel w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 relative bg-white dark:bg-dark-surface border border-marsala-primary/20">
        
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-marsala-primary dark:text-pink-100">Configurações</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 dark:hover:bg-white/10 rounded-full transition-colors text-gray-500 dark:text-gray-300">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-8">
           <div className="space-y-4">
              <h3 className="text-xs font-black text-marsala-primary/60 dark:text-pink-300/60 uppercase tracking-widest flex items-center gap-2">
                <Globe size={14}/> Idioma e Região
              </h3>
              <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-black/20">
                 <div className="flex items-center gap-3 text-gray-800 dark:text-gray-200">
                    <span className="text-xl">🇧🇷</span>
                    <span className="font-bold">Português (Brasil)</span>
                 </div>
                 <span className="text-xs font-black text-marsala-primary">PADRÃO</span>
              </div>
           </div>

           <div className="space-y-4">
              <h3 className="text-xs font-black text-marsala-primary/60 dark:text-pink-300/60 uppercase tracking-widest flex items-center gap-2">
                <Shield size={14}/> Preferências do Sistema
              </h3>
              <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-black/20">
                 <div className="flex items-center gap-3 text-gray-800 dark:text-gray-200">
                    <div className="bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-300 p-2.5 rounded-lg"><Moon size={20}/></div>
                    <span className="font-bold">Modo Escuro Ativo</span>
                 </div>
                 <span className="text-xs text-gray-400 italic">Controlado no cabeçalho</span>
              </div>
           </div>
        </div>

        <div className="p-4 bg-gray-50 dark:bg-black/30 text-center border-t border-gray-200 dark:border-gray-700">
           <span className="text-[10px] text-gray-400 font-black uppercase tracking-[0.2em]">
             Doce Tradição • V 2.4.0 Stable
           </span>
        </div>

      </div>
    </div>
  );
};
