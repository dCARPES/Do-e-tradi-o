
import React, { useState } from 'react';
import { Heart, Eye, EyeOff, User, Lock, Maximize, Minimize, Sparkles, Code2 } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (username: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'Edemar' && password === 'docedoce') {
      onLogin(username);
    } else {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center p-4 z-[100]">
      <div className="absolute inset-0 bg-marsala-soft dark:bg-black transition-colors duration-500">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#964b5c_1.5px,transparent_1.5px)] [background-size:24px_24px]"></div>
      </div>

      {/* Botão de Fullscreen Sutil */}
      <button 
        onClick={toggleFullscreen}
        className="absolute top-6 right-6 z-[120] text-marsala-primary dark:text-pink-200 opacity-40 hover:opacity-100 transition-all duration-500 hover:scale-110 p-2 bg-white/10 rounded-full backdrop-blur-sm"
        title={isFullscreen ? "Sair da Tela Cheia" : "Tela Cheia"}
      >
        {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
      </button>

      <div className="glass-panel relative w-full max-w-md p-10 rounded-[2.5rem] shadow-[0_20px_70px_rgba(150,75,92,0.3)] z-[110] animate-in fade-in zoom-in-95 duration-500">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-marsala-primary rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg rotate-3">
             <Heart className="fill-white text-white" size={40} />
          </div>
          <h1 className="font-pacifico text-5xl text-marsala-primary dark:text-pink-200 mb-2">
            Doce Tradição
          </h1>
          <p className="text-gray-700 dark:text-gray-300 font-extrabold uppercase tracking-[0.2em] text-xs">Acesso Restrito</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="relative">
            <label className="block text-marsala-primary dark:text-pink-300 font-black mb-2.5 text-xs uppercase tracking-widest ml-1">Usuário Autorizado</label>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-marsala-primary transition-colors">
                <User size={20} />
              </div>
              <input
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-marsala-light dark:border-white/10 focus:border-marsala-primary dark:focus:border-marsala-primary outline-none bg-white text-gray-900 dark:bg-zinc-900 dark:text-white font-bold transition-all shadow-inner placeholder:text-gray-400 dark:placeholder:text-gray-600"
                placeholder="Ex: Edemar"
                required
              />
            </div>
          </div>

          <div className="relative">
            <label className="block text-marsala-primary dark:text-pink-300 font-black mb-2.5 text-xs uppercase tracking-widest ml-1">Senha de Segurança</label>
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-marsala-primary transition-colors">
                <Lock size={20} />
              </div>
              <input
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-14 py-4 rounded-2xl border-2 border-marsala-light dark:border-white/10 focus:border-marsala-primary dark:focus:border-marsala-primary outline-none bg-white text-gray-900 dark:bg-zinc-900 dark:text-white font-bold transition-all shadow-inner placeholder:text-gray-400 dark:placeholder:text-gray-600"
                placeholder="Sua chave de acesso"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-marsala-primary transition-colors p-2"
              >
                {showPassword ? <EyeOff size={22} /> : <Eye size={22} />}
              </button>
            </div>
          </div>
          
          <button
            type="submit"
            className="w-full bg-marsala-primary hover:bg-marsala-secondary text-white font-black py-5 px-4 rounded-2xl shadow-xl transform transition-all hover:scale-[1.03] active:scale-95 flex items-center justify-center gap-3 text-lg uppercase tracking-widest"
          >
            Entrar no Sistema
          </button>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/30 border-2 border-red-500 p-4 rounded-2xl animate-shake">
              <p className="text-red-700 dark:text-red-400 text-center text-sm font-black">
                ⚠️ Dados incorretos! Verifique o usuário e senha.
              </p>
            </div>
          )}
        </form>

        <div className="mt-8 pt-6 border-t border-marsala-light/20 dark:border-white/5 text-center space-y-4">
          <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-black tracking-widest opacity-50">
            Confeitaria Doce Tradição • V 2.5
          </p>

          <div className="flex flex-col items-center gap-1.5">
            {/* Giselle IA */}
            <div className="flex items-center gap-1.5 text-marsala-primary dark:text-pink-300 opacity-90 hover:opacity-100 transition-opacity">
               <Sparkles size={12} className="animate-pulse text-yellow-500" />
               <span className="text-[11px] font-bold tracking-wider font-nunito">Powered by <span className="font-black">Giselle IA</span></span>
            </div>

            {/* Team Credit */}
            <div className="text-[9px] text-gray-400 dark:text-gray-600 font-medium tracking-wide flex items-center gap-1.5 opacity-70 hover:opacity-100 transition-opacity">
               <Code2 size={10} />
               <span>Developed by <span className="font-bold text-gray-500 dark:text-gray-500">Candy Tradition Team</span></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
