
import React, { useState } from 'react';
import { Section } from '../types';
import { SALARIOS, TOTAL_SALARIOS } from '../constants';
import { 
  ChefHat, Flame, Snowflake, Box, UtensilsCrossed, 
  GripVertical, TrendingUp, Users, DollarSign, 
  Calculator, Package, PieChart as PieChartIcon, 
  BarChart3, LayoutDashboard, Wallet, UserCircle,
  Network, Star, Mail, Phone, Calendar, Clock,
  ChevronRight, Info, AlertCircle, HardHat, 
  Thermometer, Hammer, Layers
} from 'lucide-react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, 
  Tooltip, Legend, BarChart, Bar, XAxis, YAxis, 
  CartesianGrid, AreaChart, Area 
} from 'recharts';

interface ContentProps {
  activeSection: Section;
  showTutorial?: boolean;
}

type RecipeType = 'tradicional' | 'ninho' | 'casadinho';
type FinanceTab = 'geral' | 'rh' | 'materiais' | 'patrimonio';
type RHTab = 'organograma' | 'perfis';

const Card: React.FC<{ title?: string; children: React.ReactNode; className?: string; icon?: React.ReactNode }> = ({ title, children, className = '', icon }) => (
  <div className={`bg-white dark:bg-dark-surface rounded-2xl shadow-sm p-6 border border-marsala-light/40 dark:border-white/10 ${className}`}>
    {title && (
      <div className="flex items-center gap-2 mb-4">
        {icon && <div className="text-marsala-primary">{icon}</div>}
        <h3 className="font-extrabold text-lg text-marsala-primary dark:text-pink-200">{title}</h3>
      </div>
    )}
    <div className="text-gray-800 dark:text-zinc-200 font-medium">
      {children}
    </div>
  </div>
);

const SheetTable: React.FC<{ headers: string[], rows: (string|number)[][], footer?: (string|number)[], headerColor?: string }> = ({ headers, rows, footer, headerColor }) => (
  <div className="overflow-x-auto border-2 border-marsala-primary/20 dark:border-white/10 rounded-xl shadow-inner bg-white dark:bg-dark-surface">
    <table className="w-full text-xs md:text-sm text-left border-collapse">
      <thead className={`${headerColor || 'bg-marsala-light dark:bg-marsala-secondary text-marsala-primary dark:text-pink-100'} border-b-2 border-marsala-primary`}>
        <tr>
          {headers.map((h, i) => (
            <th key={i} className="p-4 border border-marsala-light/30 dark:border-white/10 font-black uppercase tracking-widest text-center whitespace-nowrap">{h}</th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-marsala-light/20 dark:divide-white/10">
        {rows.map((row, i) => (
          <tr key={i} className="hover:bg-marsala-soft/10 dark:hover:bg-white/5 transition-colors">
            {row.map((cell, j) => (
              <td key={j} className={`p-3 border border-marsala-light/20 dark:border-white/10 text-gray-800 dark:text-zinc-300 font-semibold ${typeof cell === 'string' && cell.includes('R$') ? 'font-bold text-right text-marsala-primary dark:text-pink-300' : (j > 1 ? 'text-center' : '')}`}>
                {cell}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
      {footer && (
        <tfoot className="bg-green-50 dark:bg-green-900/20">
           <tr className="border-t-2 border-green-200 dark:border-green-800">
             {footer.map((f, i) => (
               <td key={i} className={`p-4 border border-marsala-light/20 dark:border-white/10 font-black text-green-800 dark:text-green-400 ${i === footer.length - 1 ? 'text-right text-xl' : ''} ${i === 0 ? 'text-right' : ''}`} colSpan={i === 0 ? headers.length - 1 : 1}>
                 {f}
               </td>
             ))}
           </tr>
        </tfoot>
      )}
    </table>
  </div>
);

const OrgCard: React.FC<{ name: string; role: string; salary: number; colorClass: string }> = ({ name, role, salary, colorClass }) => (
  <div className={`p-5 rounded-2xl shadow-lg border-2 flex flex-col items-center justify-center text-center min-w-[190px] ${colorClass} transition-all duration-300 hover:scale-105 hover:shadow-xl`}>
    <span className="font-extrabold text-base md:text-lg mb-0.5">{name}</span>
    <span className="text-[10px] md:text-xs font-black uppercase tracking-tighter opacity-80">{role}</span>
    <div className="mt-3 py-1.5 px-3 bg-black/5 dark:bg-white/10 rounded-lg font-mono text-xs md:text-sm font-black">
      R$ {salary.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
    </div>
  </div>
);

export const DashboardContent: React.FC<ContentProps> = ({ activeSection, showTutorial }) => {
  const [selectedRecipe, setSelectedRecipe] = useState<RecipeType>('tradicional');
  const [financeTab, setFinanceTab] = useState<FinanceTab>('geral');
  const [rhTab, setRhTab] = useState<RHTab>('organograma');
  const [selectedEmp, setSelectedEmp] = useState<keyof typeof SALARIOS>('bryan');

  // Investimentos Totais da Empresa (Atualizados)
  const INVESTIMENTO_PATRIMONIAL = 155000;
  const INVESTIMENTO_MATERIAIS = 15000;
  const INVESTIMENTO_RH = TOTAL_SALARIOS;
  const INVESTIMENTO_TOTAL = INVESTIMENTO_PATRIMONIAL + INVESTIMENTO_MATERIAIS + INVESTIMENTO_RH;

  const PATRIMONIO_DETALHADO = [
    { item: 'Câmara Fria Industrial Inverter', valor: 42000, icon: Snowflake, categoria: 'Refrigeração' },
    { item: 'Bancadas e Prateleiras Aço Inox 304', valor: 35000, icon: Layers, categoria: 'Mobiliário' },
    { item: 'Forno Turbo Conector Profissional', valor: 28000, icon: Flame, categoria: 'Cocção' },
    { item: 'Fogão Industrial 6 Bocas c/ Forno', valor: 12500, icon: Flame, categoria: 'Cocção' },
    { item: 'Ar Condicionado Central 60k BTUs', valor: 18000, icon: Snowflake, categoria: 'Climatização' },
    { item: 'Panela de Brigadeiro Automática 20L', valor: 9800, icon: UtensilsCrossed, categoria: 'Produção' },
    { item: 'Panelas Fundo Triplo (Lote 24un)', valor: 6500, icon: ChefHat, categoria: 'Utensílios' },
    { item: 'Termômetros, Balanças e Precisão', valor: 3200, icon: Thermometer, categoria: 'Precisão' },
  ];

  const chartDataGeral = [
    { name: 'Patrimônio', value: INVESTIMENTO_PATRIMONIAL, color: '#3b82f6' },
    { name: 'RH (Salários)', value: INVESTIMENTO_RH, color: '#964b5c' },
    { name: 'Materiais', value: INVESTIMENTO_MATERIAIS, color: '#f59e0b' },
  ];

  const chartDataSalarios = Object.values(SALARIOS).map(s => ({
    name: s.nome,
    valor: s.salario
  }));

  const DATA = {
    tradicional: {
      name: 'Brigadeiro Tradicional',
      yield: 15,
      costTotal: 15.62,
      costIngredients: 14.49,
      costPackaging: 1.13,
      themeColor: 'from-marsala-primary to-marsala-secondary',
      accentColor: 'text-marsala-primary',
      ingredients: [
        ['Leite Condensado', 'Nestlé', '1 un', 'R$ 4,99', '1 un', 'R$ 4,99'],
        ['Creme de Leite', 'Nestlé', '1 un', 'R$ 2,89', '1 un', 'R$ 2,89'],
        ['Margarina', 'Doriana', '500g', 'R$ 7,41', '10g', 'R$ 0,15'],
        ['Achocolatado', 'Nescau', '550g', 'R$ 6,97', '40g', 'R$ 0,51'],
        ['Cacau 50%', 'Harald', '400g', 'R$ 21,67', '30g', 'R$ 1,63'],
        ['Granulado', 'Melken', '1kg', 'R$ 21,67', '200g', 'R$ 4,33'],
        ['Forminha Papel', 'Mavalério', '100un', 'R$ 2,50', '15un', 'R$ 0,38'],
        ['Forminha Plástico', 'Mavalério', '50un', 'R$ 2,49', '15un', 'R$ 0,75'],
      ],
      steps: [
        { title: 'Mistura Inicial', desc: 'Em panela fria, homogeneizar leite condensado e cacau.' },
        { title: 'Cozimento Profissional', desc: 'Fogo médio, mexendo sempre até o ponto de bloco.' },
        { title: 'Ponto Correto', desc: 'O doce deve desgrudar completamente do fundo.' },
        { title: 'Descanso e Temperagem', desc: 'Mínimo de 6 horas em temperatura ambiente ou 40min frio.' },
        { title: 'Finalização', desc: 'Porcionar bolinhas de 15g e envolver no granulado.' }
      ]
    },
    ninho: {
      name: 'Ninho com Nutella',
      yield: 15,
      costTotal: 21.75,
      costIngredients: 20.62,
      costPackaging: 1.13,
      themeColor: 'from-amber-500 to-amber-700',
      accentColor: 'text-amber-600',
      ingredients: [
        ['Leite Condensado', 'Nestlé', '1 un', 'R$ 4,99', '1 un', 'R$ 4,99'],
        ['Creme de Leite', 'Nestlé', '1 un', 'R$ 2,89', '1 un', 'R$ 2,89'],
        ['Margarina', 'Doriana', '500g', 'R$ 7,41', '10g', 'R$ 0,15'],
        ['Leite Ninho (Massa)', 'Nestlé', '400g', 'R$ 19,90', '40g', 'R$ 1,99'],
        ['Nutella (Recheio)', 'Ferrero', '650g', 'R$ 42,90', '100g', 'R$ 6,60'],
        ['Leite Ninho (Finaliz.)', 'Nestlé', '400g', 'R$ 19,90', '80g', 'R$ 4,00'],
        ['Forminha Papel', 'Mavalério', '100un', 'R$ 2,50', '15un', 'R$ 0,38'],
        ['Forminha Plástico', 'Mavalério', '50un', 'R$ 2,49', '15un', 'R$ 0,75'],
      ],
      steps: [
        { title: 'Mise en Place', desc: 'Fazer pitangas de Nutella e congelar por 30 min.' },
        { title: 'Preparo da Massa', desc: 'Leite condensado, creme de leite e Ninho em pó.' },
        { title: 'Cozimento', desc: 'Cuidado extra com o ponto, a massa branca queima mais fácil.' },
        { title: 'Montagem', desc: 'Rechear a massa morna com a Nutella congelada.' }
      ]
    },
    casadinho: {
      name: 'Casadinho Gourmet',
      yield: 15,
      costTotal: 15.62,
      costIngredients: 14.49,
      costPackaging: 1.13,
      themeColor: 'from-stone-600 to-stone-800',
      accentColor: 'text-stone-700',
      ingredients: [
        ['Leite Condensado', 'Nestlé', '1 un', 'R$ 4,99', '1 un', 'R$ 4,99'],
        ['Creme de Leite', 'Nestlé', '1 un', 'R$ 2,89', '1 un', 'R$ 2,89'],
        ['Margarina', 'Doriana', '500g', 'R$ 7,41', '10g', 'R$ 0,15'],
        ['Achocolatado', 'Nescau', '550g', 'R$ 6,97', '40g', 'R$ 0,51'],
        ['Cacau 50%', 'Harald', '400g', 'R$ 21,67', '30g', 'R$ 1,63'],
        ['Granulado', 'Melken', '1000g', 'R$ 21,67', '200g', 'R$ 4,33'],
        ['Forminha Papel', 'Mavalério', '100un', 'R$ 2,50', '15un', 'R$ 0,38'],
        ['Forminha Plástico', 'Mavalério', '50un', 'R$ 2,49', '15un', 'R$ 0,75'],
      ],
      steps: [
        { title: 'Massa Branca', desc: 'Preparar base de leite condensado tradicional.' },
        { title: 'Massa Preta', desc: 'Preparar base com cacau 50% para contraste.' },
        { title: 'União', desc: 'Enrolar ambas as massas juntas para o efeito espiral.' }
      ]
    }
  };

  const currentData = DATA[selectedRecipe];

  const renderSection = () => {
    switch(activeSection) {
      case Section.DASHBOARD:
        return (
          <div className="space-y-8 animate-in fade-in duration-500 relative">
             {showTutorial && (
               <div className="absolute top-2 left-2 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
                 3
               </div>
             )}
             {/* Hero Section */}
             <div className={`bg-gradient-to-r ${currentData.themeColor} rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group`}>
                <div className="absolute -top-10 -right-10 opacity-10 group-hover:scale-110 transition-transform duration-700">
                   <UtensilsCrossed size={300} />
                </div>
                <div className="relative z-10">
                   <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div className="space-y-2">
                         <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest backdrop-blur-md">Status: Produção Ativa</span>
                         <h2 className="text-4xl md:text-5xl font-black">{currentData.name}</h2>
                         <p className="text-white/70 font-bold max-w-lg">Resumo operacional e financeiro do lote atual de produção industrial.</p>
                      </div>
                      <div className="flex gap-2 bg-black/20 p-1.5 rounded-2xl backdrop-blur-xl border border-white/10">
                         {(['tradicional', 'ninho', 'casadinho'] as RecipeType[]).map((r) => (
                            <button 
                               key={r}
                               onClick={() => setSelectedRecipe(r)}
                               className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all ${selectedRecipe === r ? 'bg-white text-marsala-primary shadow-xl' : 'hover:bg-white/10'}`}
                            >
                               {r}
                            </button>
                         ))}
                      </div>
                   </div>
                </div>
             </div>

             {/* Métricas de Topo */}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white dark:bg-dark-surface p-6 rounded-3xl border border-marsala-light/20 shadow-sm flex items-center gap-5 group hover:shadow-xl transition-all border-b-4 border-b-blue-500">
                   <div className="w-14 h-14 bg-blue-50 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center text-blue-600 shrink-0 group-hover:rotate-12 transition-transform">
                      <Box size={28} />
                   </div>
                   <div>
                      <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Rendimento Lote</span>
                      <span className="text-3xl font-black text-gray-900 dark:text-white">{currentData.yield} <span className="text-sm opacity-50">doces</span></span>
                   </div>
                </div>
                
                <div className="bg-white dark:bg-dark-surface p-6 rounded-3xl border border-marsala-light/20 shadow-sm flex items-center gap-5 group hover:shadow-xl transition-all border-b-4 border-b-green-500">
                   <div className="w-14 h-14 bg-green-50 dark:bg-green-900/30 rounded-2xl flex items-center justify-center text-green-600 shrink-0 group-hover:rotate-12 transition-transform">
                      <DollarSign size={28} />
                   </div>
                   <div>
                      <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Custo Insumos</span>
                      <span className="text-3xl font-black text-gray-900 dark:text-white">R$ {currentData.costTotal.toFixed(2)}</span>
                   </div>
                </div>

                <div className="bg-white dark:bg-dark-surface p-6 rounded-3xl border border-marsala-light/20 shadow-sm flex items-center gap-5 group hover:shadow-xl transition-all border-b-4 border-b-purple-500">
                   <div className="w-14 h-14 bg-purple-50 dark:bg-purple-900/30 rounded-2xl flex items-center justify-center text-purple-600 shrink-0 group-hover:rotate-12 transition-transform">
                      <Users size={28} />
                   </div>
                   <div>
                      <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Mão de Obra</span>
                      <span className="text-3xl font-black text-gray-900 dark:text-white">10 <span className="text-sm opacity-50">especialistas</span></span>
                   </div>
                </div>
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                {/* Timeline de Preparo - Layout Ajustado */}
                <div className="lg:col-span-3">
                   <Card title="Fluxo de Produção" icon={<Clock size={20} />}>
                      <div className="relative space-y-8">
                         {/* Linha Vertical Corrigida */}
                         <div className="absolute left-[27px] top-2 bottom-2 w-0.5 bg-marsala-light/40 dark:bg-white/10"></div>
                         
                         {currentData.steps.map((step, i) => (
                            <div key={i} className="relative flex items-start gap-4 group">
                               {/* Bullet Container - Largura Fixa para Alinhamento */}
                               <div className="w-14 flex justify-center shrink-0 relative z-10">
                                  <div className="w-5 h-5 mt-1 rounded-full bg-white dark:bg-dark-surface border-4 border-marsala-primary group-hover:scale-125 transition-transform shadow-sm"></div>
                               </div>
                               
                               {/* Texto com Espaçamento Correto */}
                               <div className="flex flex-col pt-0.5">
                                  <span className="text-xs font-black text-marsala-primary uppercase tracking-widest mb-1">Passo {i+1}</span>
                                  <h4 className="font-bold text-gray-900 dark:text-white leading-tight mb-1">{step.title}</h4>
                                  <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{step.desc}</p>
                               </div>
                            </div>
                         ))}
                      </div>
                   </Card>
                </div>

                {/* Insumos e Distribuição */}
                <div className="lg:col-span-2 space-y-8">
                   <Card title="Peso dos Insumos" icon={<BarChart3 size={20} />}>
                      <div className="space-y-5">
                         {currentData.ingredients.slice(0, 5).map((ing, i) => {
                            const valStr = ing[5] as string;
                            const val = parseFloat(valStr.replace('R$ ', '').replace(',', '.'));
                            const percentage = (val / currentData.costTotal) * 100;
                            return (
                               <div key={i} className="space-y-1.5">
                                  <div className="flex justify-between text-xs font-black uppercase tracking-tighter">
                                     <span className="text-gray-600 dark:text-gray-400 truncate max-w-[150px]">{ing[0]}</span>
                                     <span className={currentData.accentColor}>{valStr}</span>
                                  </div>
                                  <div className="h-2 w-full bg-gray-100 dark:bg-white/5 rounded-full overflow-hidden">
                                     <div 
                                        className={`h-full rounded-full transition-all duration-1000 bg-gradient-to-r ${currentData.themeColor}`} 
                                        style={{ width: `${percentage}%` }}
                                     ></div>
                                  </div>
                               </div>
                            )
                         })}
                      </div>
                      <div className="mt-6 pt-4 border-t border-gray-100 dark:border-white/5 flex items-center justify-between text-[10px] font-black uppercase text-gray-400 tracking-widest">
                         <span>Análise: Top 5 Insumos</span>
                         <span className="flex items-center gap-1"><Info size={12}/> Detalhes em Rec. Materiais</span>
                      </div>
                   </Card>

                   <div className="bg-amber-50 dark:bg-amber-900/20 p-6 rounded-3xl border border-amber-200 dark:border-amber-800 flex flex-col items-center text-center">
                      <AlertCircle className="text-amber-600 mb-3" size={32} />
                      <h4 className="font-black text-amber-800 dark:text-amber-200 text-sm uppercase mb-2">Lembrete de Qualidade</h4>
                      <p className="text-xs text-amber-700/80 font-bold leading-relaxed">
                         "A qualidade do doce é o nosso maior patrimônio. Verifique sempre o ponto de bloco para garantir a textura ideal."
                      </p>
                   </div>
                </div>
             </div>
          </div>
        );

      case Section.RH:
        return (
          <div className="animate-in fade-in zoom-in-95 duration-500 space-y-8 pb-10 relative">
             {showTutorial && (
               <div className="absolute top-2 right-2 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
                 3
               </div>
             )}
            <div className="text-center mb-6">
              <h2 className="font-pacifico text-4xl text-marsala-primary dark:text-pink-200 mb-2">Recursos Humanos e Organograma</h2>
              <div className="h-1 w-24 bg-marsala-primary dark:bg-pink-400 mx-auto rounded-full"></div>
            </div>

            {/* Sub-menu de RH */}
            <div className="flex gap-2 bg-white/50 dark:bg-black/20 p-1.5 rounded-2xl border border-marsala-primary/10 max-w-2xl mx-auto">
                <button onClick={() => setRhTab('organograma')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-black transition-all ${rhTab === 'organograma' ? 'bg-marsala-primary text-white shadow-lg' : 'text-gray-500 hover:bg-marsala-soft/20'}`}><Network size={18}/> Organograma</button>
                <button onClick={() => setRhTab('perfis')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-black transition-all ${rhTab === 'perfis' ? 'bg-marsala-primary text-white shadow-lg' : 'text-gray-500 hover:bg-marsala-soft/20'}`}><UserCircle size={18}/> Perfis da Equipe</button>
            </div>

            {rhTab === 'organograma' ? (
              <div className="overflow-x-auto p-4 flex flex-col items-center gap-8 custom-scrollbar">
                <div className="flex justify-center">
                  <OrgCard name={SALARIOS.bryan.nome} role={SALARIOS.bryan.cargo} salary={SALARIOS.bryan.salario} colorClass="bg-white dark:bg-marsala-primary text-marsala-primary dark:text-white border-marsala-primary dark:border-pink-300 border-4" />
                </div>
                <div className="w-1.5 h-12 bg-marsala-primary/60 dark:bg-pink-400/50"></div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto relative">
                  <div className="flex flex-col items-center gap-4">
                    <OrgCard name={SALARIOS.anielli.nome} role={SALARIOS.anielli.cargo} salary={SALARIOS.anielli.salario} colorClass="bg-cyan-50 dark:bg-cyan-900 text-cyan-800 dark:text-cyan-100 border-cyan-200" />
                    <OrgCard name={SALARIOS.iasmin.nome} role={SALARIOS.iasmin.cargo} salary={SALARIOS.iasmin.salario} colorClass="bg-cyan-50/50 text-cyan-700 border-cyan-100" />
                  </div>
                  <div className="flex flex-col items-center gap-4">
                    <OrgCard name={SALARIOS.emily.nome} role={SALARIOS.emily.cargo} salary={SALARIOS.emily.salario} colorClass="bg-blue-50 dark:bg-blue-900 text-blue-800 dark:text-blue-100 border-blue-200" />
                    <OrgCard name={SALARIOS.jakelyne.nome} role={SALARIOS.jakelyne.cargo} salary={SALARIOS.jakelyne.salario} colorClass="bg-blue-50/50 text-blue-700 border-blue-100" />
                  </div>
                  <div className="flex flex-col items-center gap-4">
                    <OrgCard name={SALARIOS.felipe.nome} role={SALARIOS.felipe.cargo} salary={SALARIOS.felipe.salario} colorClass="bg-indigo-50 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-100 border-indigo-200" />
                    <OrgCard name={SALARIOS.luis.nome} role={SALARIOS.luis.cargo} salary={SALARIOS.luis.salario} colorClass="bg-indigo-50/50 text-indigo-700 border-indigo-100" />
                  </div>
                  <div className="flex flex-col items-center gap-4">
                    <OrgCard name={SALARIOS.edemar.nome} role={SALARIOS.edemar.cargo} salary={SALARIOS.edemar.salario} colorClass="bg-zinc-900 text-white border-zinc-800" />
                    <OrgCard name={SALARIOS.barbara.nome} role={SALARIOS.barbara.cargo} salary={SALARIOS.barbara.salario} colorClass="bg-zinc-800 text-zinc-100" />
                    <OrgCard name={SALARIOS.ana.nome} role={SALARIOS.ana.cargo} salary={SALARIOS.ana.salario} colorClass="bg-zinc-700 text-zinc-200" />
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 px-4 animate-in fade-in duration-300">
                <Card className="md:col-span-1 p-2 space-y-1 bg-white/50">
                  <h4 className="px-4 py-2 text-[10px] font-black uppercase text-gray-400 tracking-widest">Equipe</h4>
                  {Object.entries(SALARIOS).map(([key, person]) => (
                    <button key={key} onClick={() => setSelectedEmp(key as keyof typeof SALARIOS)} className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${selectedEmp === key ? 'bg-marsala-primary text-white shadow-md' : 'hover:bg-marsala-soft/40 text-gray-600 dark:text-gray-300'}`}>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 font-black text-xs ${selectedEmp === key ? 'bg-white/20 text-white' : 'bg-marsala-primary/10 text-marsala-primary dark:bg-white/10 dark:text-white'}`}>
                        {person.nome.substring(0, 1)}
                      </div>
                      <div className="truncate">
                        <div className="font-bold text-sm leading-tight">{person.nome}</div>
                        <div className={`text-[10px] uppercase font-black opacity-60 ${selectedEmp === key ? 'text-white' : 'text-marsala-primary'}`}>{person.cargo}</div>
                      </div>
                    </button>
                  ))}
                </Card>
                <Card className="md:col-span-3 border-l-8 border-marsala-primary bg-gradient-to-br from-white to-marsala-soft/10 overflow-hidden relative">
                   <div className="relative z-10 flex flex-col gap-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-marsala-primary/10 pb-6">
                        <div>
                          <div className="flex items-center gap-3">
                             <h3 className="text-4xl font-black text-marsala-primary dark:text-pink-200">{SALARIOS[selectedEmp].nome}</h3>
                             <div className="bg-green-500/10 text-green-600 dark:text-green-400 px-3 py-1 rounded-full font-black text-[10px] uppercase tracking-widest border border-green-500/20">Membro Ativo</div>
                          </div>
                          <p className="text-lg font-bold text-gray-500 uppercase tracking-tighter mt-1">{SALARIOS[selectedEmp].cargo}</p>
                        </div>
                        <div className="text-right hidden md:block">
                           <div className="text-3xl font-black text-marsala-primary">R$ {SALARIOS[selectedEmp].salario.toLocaleString('pt-BR')}</div>
                           <div className="text-xs font-bold text-gray-400 uppercase tracking-widest">Remuneração Mensal</div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-6">
                             <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 flex items-center gap-2"><UserCircle size={14}/> Contato & Dados</h4>
                             <div className="grid grid-cols-1 gap-4">
                               <div className="flex items-start gap-3 text-gray-600 dark:text-gray-300 font-bold">
                                  <Mail className="text-marsala-primary shrink-0 mt-0.5" size={18}/> 
                                  <span className="text-xs break-all leading-tight">{SALARIOS[selectedEmp].email}</span>
                               </div>
                               <div className="flex items-center gap-3 text-gray-600 dark:text-gray-300 font-bold">
                                  <Phone className="text-marsala-primary shrink-0" size={18}/> 
                                  {SALARIOS[selectedEmp].phone}
                               </div>
                               <div className="flex items-center gap-3 text-gray-600 dark:text-gray-300 font-bold">
                                  <Calendar className="text-marsala-primary shrink-0" size={18}/> 
                                  Desde 2025
                               </div>
                               <div className="flex md:hidden items-center gap-3 text-marsala-primary font-black">
                                  <DollarSign size={18} className="shrink-0"/> 
                                  R$ {SALARIOS[selectedEmp].salario.toLocaleString('pt-BR')} /mês
                               </div>
                            </div>
                        </div>

                        <div className="space-y-6">
                             <div className="space-y-2">
                               <h4 className="text-xs font-black uppercase tracking-widest text-gray-400">Biografia</h4>
                               <p className="text-gray-700 dark:text-gray-300 leading-relaxed italic bg-white/50 dark:bg-black/20 p-4 rounded-xl border border-marsala-primary/5">"{SALARIOS[selectedEmp].bio}"</p>
                            </div>
                            <div className="space-y-2">
                               <h4 className="text-xs font-black uppercase tracking-widest text-gray-400">Especialidades</h4>
                               <div className="flex flex-wrap gap-2">
                                  {SALARIOS[selectedEmp].skills.map((skill, i) => (
                                    <span key={i} className="px-3 py-1 bg-marsala-soft/30 dark:bg-white/10 text-marsala-primary dark:text-pink-200 rounded-lg text-xs font-black border border-marsala-primary/20">{skill}</span>
                                  ))}
                               </div>
                            </div>
                        </div>
                      </div>
                   </div>
                </Card>
              </div>
            )}
          </div>
        );

      case Section.PATRIMONIO:
        return (
          <div className="space-y-8 animate-in fade-in duration-300 relative">
              {showTutorial && (
               <div className="absolute top-2 right-2 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
                 3
               </div>
             )}
              <div className="text-center">
                 <h2 className="font-pacifico text-4xl text-blue-600 dark:text-blue-300 mb-2">Inventário Patrimonial</h2>
                 <p className="text-xs font-black uppercase tracking-[0.2em] text-gray-400">Maquinário e Ativos Fixos</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                 {PATRIMONIO_DETALHADO.slice(0, 4).map((item, idx) => (
                    <div key={idx} className="bg-white dark:bg-dark-surface p-6 rounded-3xl border border-blue-100 dark:border-blue-900/40 shadow-sm flex flex-col items-center text-center gap-3">
                       <div className="p-4 bg-blue-50 dark:bg-blue-900/30 text-blue-600 rounded-2xl"><item.icon size={32}/></div>
                       <div>
                          <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{item.categoria}</span>
                          <h4 className="font-bold text-gray-900 dark:text-white text-sm leading-tight mb-2">{item.item}</h4>
                          <span className="text-xl font-black text-blue-600">R$ {item.valor.toLocaleString('pt-BR')}</span>
                       </div>
                    </div>
                 ))}
              </div>

              <Card title="Detalhamento Completo de Ativos">
                 <SheetTable 
                    headers={['Ativo / Maquinário', 'Categoria', 'Valor de Mercado (Est.)']}
                    rows={PATRIMONIO_DETALHADO.map(p => [p.item, p.categoria, `R$ ${p.valor.toLocaleString('pt-BR')}`])}
                    footer={['VALOR PATRIMONIAL TOTAL', `R$ ${INVESTIMENTO_PATRIMONIAL.toLocaleString('pt-BR')}`]}
                    headerColor="bg-blue-600 text-white"
                 />
              </Card>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-[2rem] border-2 border-dashed border-blue-200 dark:border-blue-800 flex flex-col items-center text-center">
                 <HardHat className="text-blue-500 mb-2" size={24}/>
                 <h5 className="font-black text-blue-800 dark:text-blue-200 text-xs uppercase tracking-widest">Plano de Manutenção Ativo</h5>
                 <p className="text-[10px] text-blue-700/70 font-bold max-w-md mt-1">Todos os equipamentos de cocção e refrigeração passam por revisão trimestral preventiva para garantir a padronização térmica da produção.</p>
              </div>
          </div>
        );

      case Section.MATERIAIS:
        return (
          <div className="animate-in fade-in duration-300 space-y-6 relative">
            {showTutorial && (
               <div className="absolute top-2 right-2 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
                 3
               </div>
             )}
            <div className="flex flex-wrap justify-center gap-2 bg-gray-100 dark:bg-black/40 p-1.5 rounded-xl w-full">
              <button onClick={() => setSelectedRecipe('tradicional')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-black transition-all flex-1 justify-center ${selectedRecipe === 'tradicional' ? 'bg-marsala-primary text-white shadow-md' : 'text-gray-600 dark:text-gray-400 hover:text-marsala-primary'}`}><Box size={18} /> Tradicional</button>
              <button onClick={() => setSelectedRecipe('ninho')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-black transition-all flex-1 justify-center ${selectedRecipe === 'ninho' ? 'bg-amber-500 text-white shadow-md' : 'text-gray-600 dark:text-gray-400 hover:text-amber-500'}`}><UtensilsCrossed size={18} /> Ninho c/ Nutella</button>
              <button onClick={() => setSelectedRecipe('casadinho')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-black transition-all flex-1 justify-center ${selectedRecipe === 'casadinho' ? 'bg-stone-600 text-white shadow-md' : 'text-gray-600 dark:text-gray-400 hover:text-stone-400'}`}><GripVertical size={18} /> Casadinho</button>
            </div>
            
            <SheetTable 
              headers={['Insumo', 'Marca', 'Qtd Compra', 'Custo Aquisição', 'Uso Receita', 'Custo Proporcional']}
              rows={currentData.ingredients}
              footer={['INVESTIMENTO TOTAL DO LOTE', `R$ ${currentData.costTotal.toFixed(2)}`]}
              headerColor={`bg-gradient-to-r ${currentData.themeColor} text-white`}
            />
          </div>
        );

      case Section.FINANCEIRO:
        return (
          <div className="animate-in fade-in duration-300 space-y-6 relative">
             {showTutorial && (
               <div className="absolute top-2 right-2 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
                 3
               </div>
             )}
             {/* Header com Resumo Global Recalculado */}
             <div className="bg-marsala-primary text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10 rotate-12"><Calculator size={200} /></div>
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                   <div className="text-center md:text-left">
                      <span className="font-black uppercase tracking-widest text-xs opacity-80 flex items-center gap-2 justify-center md:justify-start"><Wallet size={16}/> Investimento Global Estrutural</span>
                      <h2 className="text-5xl md:text-7xl font-black mt-2 drop-shadow-lg"><span className="text-2xl opacity-60 mr-1">R$</span>{INVESTIMENTO_TOTAL.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h2>
                      <p className="mt-2 text-sm font-bold text-pink-100/70 italic">Ativos Fixos + RH + Capital de Giro (Materiais)</p>
                   </div>
                   <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 flex gap-4 text-center">
                      <div>
                         <span className="block text-[10px] uppercase font-black opacity-60 text-blue-100">Patrimônio</span>
                         <span className="font-bold">R$ {INVESTIMENTO_PATRIMONIAL.toLocaleString('pt-BR')}</span>
                      </div>
                      <div className="w-px bg-white/20"></div>
                      <div>
                         <span className="block text-[10px] uppercase font-black opacity-60 text-pink-100">Folha (RH)</span>
                         <span className="font-bold">R$ {INVESTIMENTO_RH.toLocaleString('pt-BR')}</span>
                      </div>
                   </div>
                </div>
             </div>

             {/* Sub-Tabs */}
             <div className="flex gap-2 bg-white/50 dark:bg-black/20 p-1.5 rounded-2xl border border-marsala-primary/10">
                {[{ id: 'geral', label: 'Geral', icon: LayoutDashboard }, { id: 'rh', label: 'RH', icon: Users }, { id: 'materiais', label: 'Materiais', icon: Package }, { id: 'patrimonio', label: 'Patrimônio', icon: ChefHat }].map(tab => (
                  <button key={tab.id} onClick={() => setFinanceTab(tab.id as FinanceTab)} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-black transition-all ${financeTab === tab.id ? 'bg-marsala-primary text-white shadow-lg' : 'text-gray-500 hover:bg-marsala-soft/20'}`}><tab.icon size={18}/><span className="hidden sm:inline">{tab.label}</span></button>
                ))}
             </div>

             {/* Gráfico Geral com Novas Proporções */}
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2 min-h-[400px] flex flex-col" title={`Composição: ${financeTab.toUpperCase()}`}>
                   <div className="flex-1 w-full h-full min-h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                         {financeTab === 'geral' ? (
                            <PieChart>
                               <Pie data={chartDataGeral} cx="50%" cy="50%" innerRadius={80} outerRadius={120} paddingAngle={5} dataKey="value">
                                 {chartDataGeral.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.color} />))}
                               </Pie>
                               <Tooltip contentStyle={{ borderRadius: '16px', fontWeight: 'bold' }} formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}/>
                               <Legend verticalAlign="bottom" height={36}/>
                            </PieChart>
                         ) : financeTab === 'rh' ? (
                            <BarChart data={chartDataSalarios}>
                               <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                               <XAxis dataKey="name" fontSize={10} tick={{fontWeight: 'bold'}} />
                               <YAxis fontSize={10} />
                               <Tooltip cursor={{fill: 'rgba(150, 75, 92, 0.1)'}} contentStyle={{ borderRadius: '16px', fontWeight: 'bold' }}/>
                               <Bar dataKey="valor" fill="#964b5c" radius={[8, 8, 0, 0]} />
                            </BarChart>
                         ) : financeTab === 'patrimonio' ? (
                            <BarChart layout="vertical" data={PATRIMONIO_DETALHADO} margin={{ left: 40, right: 20 }}>
                               <XAxis type="number" hide />
                               <YAxis dataKey="item" type="category" width={150} fontSize={8} tick={{fontWeight: 'bold'}} />
                               <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', fontSize: '12px' }} formatter={(v: number) => `R$ ${v.toLocaleString('pt-BR')}`} />
                               <Bar dataKey="valor" fill="#3b82f6" radius={[0, 10, 10, 0]} />
                            </BarChart>
                         ) : (
                            <AreaChart data={[{m: 'Sem 1', v: 3500}, {m: 'Sem 2', v: 4200}, {m: 'Sem 3', v: 3800}, {m: 'Sem 4', v: 3500}]}>
                               <XAxis dataKey="m" />
                               <YAxis />
                               <Tooltip contentStyle={{ borderRadius: '16px', fontWeight: 'bold' }} />
                               <Area type="monotone" dataKey="v" stroke="#f59e0b" fill="#f59e0b22" />
                            </AreaChart>
                         )}
                      </ResponsiveContainer>
                   </div>
                </Card>

                <div className="space-y-6">
                   <Card title="Detalhamento">
                      <div className="space-y-4">
                         {financeTab === 'geral' && chartDataGeral.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-white/5 rounded-xl border-l-4" style={{ borderColor: item.color }}>
                               <span className="text-sm font-black text-gray-600">{item.name}</span>
                               <span className="font-mono font-bold">R$ {item.value.toLocaleString('pt-BR')}</span>
                            </div>
                         ))}
                         {financeTab === 'patrimonio' && (
                            <div className="text-center p-4">
                               <p className="text-xs text-gray-500 uppercase font-black mb-1">Total Ativos Fixos</p>
                               <span className="text-3xl font-black text-blue-600">R$ {INVESTIMENTO_PATRIMONIAL.toLocaleString('pt-BR')}</span>
                               <div className="mt-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">Base: Equipamentos Industriais</div>
                            </div>
                         )}
                         {financeTab === 'rh' && (
                            <div className="text-center p-4">
                               <p className="text-xs text-gray-500 uppercase font-black mb-1">Total Salários</p>
                               <span className="text-3xl font-black text-marsala-primary">R$ {TOTAL_SALARIOS.toLocaleString('pt-BR')}</span>
                               <div className="mt-4 text-[10px] text-gray-400 font-bold uppercase tracking-widest">10 Colaboradores Ativos</div>
                            </div>
                         )}
                         {financeTab === 'materiais' && (
                            <div className="space-y-3">
                               <div className="flex justify-between text-xs font-bold opacity-70 italic"><span>Categoria</span><span>Valor Est.</span></div>
                               <div className="flex justify-between text-sm font-black border-b border-gray-100 pb-1"><span>Matéria Prima</span><span>R$ 12.000,00</span></div>
                               <div className="flex justify-between text-sm font-black border-b border-gray-100 pb-1"><span>Descartáveis</span><span>R$ 3.000,00</span></div>
                            </div>
                         )}
                      </div>
                   </Card>

                   <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-3xl border border-blue-100 dark:border-blue-800 flex flex-col items-center text-center">
                      <Star className="text-blue-500 mb-2" size={24}/>
                      <h4 className="font-black text-blue-800 dark:text-blue-200 text-xs uppercase mb-1">Indicador Patrimonial</h4>
                      <p className="text-[10px] text-blue-600/80 font-bold">72% do capital da empresa está imobilizado em maquinário industrial de alta eficiência.</p>
                   </div>
                </div>
             </div>
          </div>
        );

      default:
        return <div className="p-20 text-center font-bold text-gray-400">Seção em Construção</div>;
    }
  };

  return <div className="animate-in fade-in slide-in-from-right-8 duration-500">{renderSection()}</div>;
};
