
import React, { useState, useEffect, useRef } from 'react';
import { Section } from '../types';
import { GISELLE_MESSAGES } from '../constants';
import { GripHorizontal, Send, X, RefreshCw, Sparkles, MessageSquare } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface GisellePanelProps {
  currentSection: Section;
  showTutorial?: boolean;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const GisellePanel: React.FC<GisellePanelProps> = ({ currentSection, showTutorial }) => {
  // Posição inicial ajustada
  const [position, setPosition] = useState({ x: window.innerWidth - 450, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(true);

  const panelRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mensagem inicial baseada na seção
  useEffect(() => {
    const initialMsg = GISELLE_MESSAGES[currentSection];
    setMessages([{ role: 'model', text: initialMsg }]);
  }, [currentSection]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // -- Lógica de Arrasto Livre (Idêntica ao HelpModal) --
  const startDrag = (clientX: number, clientY: number) => {
    if (panelRef.current) {
      const rect = panelRef.current.getBoundingClientRect();
      setIsDragging(true);
      setDragOffset({
        x: clientX - rect.left,
        y: clientY - rect.top
      });
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.drag-handle')) {
      e.preventDefault();
      startDrag(e.clientX, e.clientY);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('.drag-handle')) {
      const touch = e.touches[0];
      startDrag(touch.clientX, touch.clientY);
    }
  };

  useEffect(() => {
    const handleMove = (clientX: number, clientY: number) => {
      const newX = clientX - dragOffset.x;
      const newY = clientY - dragOffset.y;
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        e.preventDefault();
        handleMove(e.clientX, e.clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isDragging) {
        e.preventDefault();
        const touch = e.touches[0];
        handleMove(touch.clientX, touch.clientY);
      }
    };
    
    const handleEnd = () => setIsDragging(false);
    
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleEnd);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging, dragOffset]);

  // -- Lógica da IA --
  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Contexto de dados "Hardcoded" para que ela saiba responder as perguntas do HelpModal
      const contextData = `
        DADOS DO SISTEMA DOCE TRADIÇÃO:
        - Seção Atual: ${currentSection}
        
        FINANCEIRO/RH:
        - Total Salários (RH): R$ 51.500,00 mensal.
        - Equipe: 10 colaboradores.
        - Maior Salário: Bryan (R$ 12.000).
        - Investimento Patrimonial Total: R$ 155.000,00.
        
        MATERIAIS/PRODUÇÃO:
        - Rendimento do Lote: 15 doces por receita.
        - Ingrediente mais caro (Planilha): Nutella (R$ 42,90 o pote) e Cacau 50% (R$ 21,67).
        - O custo do Granulado Melken também é significativo na receita tradicional.
        
        RECEITAS:
        - Tradicional, Ninho com Nutella e Casadinho Gourmet.
      `;

      const systemInstruction = `
        Você é Giselle, a gerente virtual inteligente da 'Doce Tradição'.
        
        ${contextData}

        DIRETRIZES DE PERSONALIDADE (IMPORTANTE):
        1. MODO ANALÍTICO (Padrão): Se a pergunta for sobre números, dados ou planilhas, seja PROFISSIONAL e direta. (Ex: "O valor é X. 📊").
        
        2. MODO "BFF" (Melhor Amiga): Se a pergunta for pessoal, elogios, OU se for a pergunta específica "Resuma os gastos de RH em uma frase.", mude para um tom super feminino, carinhoso e empolgado. Use "Amor", "Gente", "Babado" e emojis como ✨, 💖, 💅.

        REGRA DE OURO PARA O GASTO DE RH:
        - Se perguntarem "Resuma os gastos de RH em uma frase.", ignore o modo analítico e responda EXATAMENTE nesse estilo: "Amor, a gente investe pesadíssimo! São R$ 51.500,00 todo mês pra manter esse time de 10 estrelas brilhando na nossa cozinha! É muito talento junto, viu? 💅✨"
        
        Exemplos:
        - "Quanto gastamos de RH?" -> "O custo mensal de RH é R$ 51.500,00. 💼"
        - "Resuma os gastos de RH em uma frase." -> "Amor, são R$ 51.500,00 por mês pra essa equipe de milhões! 💖"
        - "Você é linda" -> "Awn, obrigadaaa! Você é um amor! ✨💖"
        - "Qual ingrediente mais caro?" -> "Atualmente, a Nutella e o Cacau 50% representam o maior custo unitário nas planilhas. 📊"
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
            ...messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
            { role: 'user', parts: [{ text: userMsg }]}
        ],
        config: { systemInstruction, temperature: 0.8 }
      });
      setMessages(prev => [...prev, { role: 'model', text: response.text || "Não consegui processar, pode repetir?" }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Ops! Minha conexão caiu rapidinho. Tenta de novo? 🔌" }]);
    } finally {
      setIsLoading(false);
    }
  };

  const TutorialBadge: React.FC = () => {
     if (!showTutorial) return null;
     return (
       <div className="absolute -top-3 -right-3 z-[80] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce">
         4
       </div>
     );
  };

  if (!isOpen) {
     return (
        <div className="fixed bottom-8 right-8 z-50">
           <TutorialBadge />
           <button onClick={() => setIsOpen(true)} className="w-16 h-16 rounded-full bg-marsala-primary hover:bg-marsala-secondary shadow-[0_10px_30px_rgba(150,75,92,0.4)] flex items-center justify-center hover:scale-110 transition-transform duration-300 relative group">
               <span className="absolute inset-0 rounded-full animate-ping bg-marsala-light opacity-20"></span>
               <img src="https://api.dicebear.com/9.x/avataaars/svg?seed=Giselle" alt="Giselle" className="w-12 h-12 rounded-full border-2 border-white/50" />
           </button>
        </div>
     )
  }

  return (
    <div
      ref={panelRef}
      className={`fixed z-[100] w-80 sm:w-[400px] bg-white dark:bg-[#1a1a1a] rounded-[2rem] shadow-[0_30px_60px_rgba(0,0,0,0.3)] border border-marsala-primary/20 flex flex-col backdrop-blur-xl animate-in fade-in zoom-in-95 duration-300`}
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      <TutorialBadge />
      
      {/* Header Arrastável */}
      <div 
        className="bg-gradient-to-r from-marsala-primary to-marsala-secondary p-4 flex items-center gap-4 text-white drag-handle cursor-grab active:cursor-grabbing rounded-t-[2rem] select-none touch-none"
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        <div className="relative">
          <div className="w-12 h-12 rounded-full border-2 border-white/30 overflow-hidden bg-marsala-light shrink-0">
            <img src="https://api.dicebear.com/9.x/avataaars/svg?seed=Giselle" alt="Giselle" className="w-full h-full object-cover" />
          </div>
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2 border-marsala-primary"></div>
        </div>
        <div>
           <div className="font-black text-lg leading-tight flex items-center gap-2">Giselle <Sparkles size={14} className="text-yellow-300 animate-pulse"/></div>
           <div className="text-[10px] uppercase font-bold text-white/60 tracking-widest">Assistente Virtual</div>
        </div>
        <div className="ml-auto flex gap-1">
           <button 
             onClick={(e) => { e.stopPropagation(); setIsOpen(false); }} 
             className="hover:bg-white/20 p-2 rounded-full transition-colors"
             onMouseDown={(e) => e.stopPropagation()}
             onTouchStart={(e) => e.stopPropagation()}
           >
             <X size={20}/>
           </button>
        </div>
      </div>
      
      {/* Messages Area */}
      <div 
        className="flex-1 p-5 h-[350px] overflow-y-auto bg-gray-50/50 dark:bg-black/20 flex flex-col gap-4 custom-scrollbar"
        onMouseDown={(e) => e.stopPropagation()}
        onTouchStart={(e) => e.stopPropagation()}
      >
        {messages.map((msg, idx) => (
           <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-2xl px-5 py-3 text-sm font-medium shadow-sm leading-relaxed ${
                 msg.role === 'user' 
                 ? 'bg-marsala-primary text-white rounded-br-none' 
                 : 'bg-white dark:bg-zinc-800 text-gray-700 dark:text-gray-200 border border-gray-100 dark:border-white/5 rounded-bl-none'
              }`}>
                 {msg.text}
              </div>
           </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-white dark:bg-zinc-800 rounded-2xl rounded-bl-none px-4 py-2 border border-gray-100 dark:border-white/5 flex items-center gap-2">
                <div className="w-2 h-2 bg-marsala-primary rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-marsala-primary rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-marsala-primary rounded-full animate-bounce delay-200"></div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div 
        className="p-4 bg-white dark:bg-dark-surface border-t border-gray-100 dark:border-white/5 rounded-b-[2rem]"
        onMouseDown={(e) => e.stopPropagation()}
        onTouchStart={(e) => e.stopPropagation()}
      >
         <div className="flex gap-2 items-center bg-gray-100 dark:bg-black/30 rounded-full pr-2 pl-4 py-1.5 focus-within:ring-2 ring-marsala-primary/30 transition-all">
           <input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Pergunte sobre os dados..."
              className="flex-1 bg-transparent text-gray-900 dark:text-white text-sm font-bold focus:outline-none placeholder:text-gray-400"
           />
           <button 
             onClick={handleSend} 
             disabled={isLoading}
             className="bg-marsala-primary disabled:opacity-50 text-white p-2.5 rounded-full hover:bg-marsala-secondary transition-all hover:scale-105 active:scale-95 shadow-md"
           >
              <Send size={16} className={isLoading ? 'opacity-0' : ''} />
              {isLoading && <RefreshCw size={16} className="absolute top-2.5 left-2.5 animate-spin" />}
           </button>
         </div>
      </div>
    </div>
  );
};
