
import React, { useState, useEffect, useRef } from 'react';
import { X, BookOpen, Info, GripHorizontal, MousePointerClick, Zap, Layout, MessageSquare, Briefcase, DollarSign, Package, PieChart, ChefHat, Sparkles } from 'lucide-react';
import { Section } from '../types';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSection: Section;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose, activeSection }) => {
  const [activeTab, setActiveTab] = useState<'instructions' | 'about'>('about');
  
  // -- Lógica de Arrastar (Livre e Suave) --
  const [position, setPosition] = useState({ x: 50, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const panelRef = useRef<HTMLDivElement>(null);

  const startDrag = (clientX: number, clientY: number) => {
    if (panelRef.current) {
      const rect = panelRef.current.getBoundingClientRect();
      setIsDragging(true);
      setDragOffset({
        x: clientX - rect.left,
        y: clientY - rect.top
      });
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    // Só arrasta se clicar no cabeçalho (classe .drag-handle)
    if ((e.target as HTMLElement).closest('.drag-handle')) {
      e.preventDefault();
      startDrag(e.clientX, e.clientY);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('.drag-handle')) {
      const touch = e.touches[0];
      startDrag(touch.clientX, touch.clientY);
    }
  };

  useEffect(() => {
    const handleMove = (clientX: number, clientY: number) => {
      const newX = clientX - dragOffset.x;
      const newY = clientY - dragOffset.y;
      
      setPosition({
        x: newX,
        y: newY 
      });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        e.preventDefault();
        handleMove(e.clientX, e.clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isDragging) {
        e.preventDefault();
        const touch = e.touches[0];
        handleMove(touch.clientX, touch.clientY);
      }
    };
    
    const handleEnd = () => setIsDragging(false);
    
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleEnd);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging, dragOffset]);

  // -- Conteúdo Dinâmico (Sincronizado com o Menu) --
  const getDynamicContent = () => {
    switch (activeSection) {
      case Section.DASHBOARD:
        return {
          title: "Visão Geral", // Exatamente como no Menu
          icon: <PieChart size={18}/>,
          desc: "O coração da operação. Aqui você acompanha o pulso da produção em tempo real. Os cards superiores mostram rendimento e valores instantâneos, enquanto a timeline detalha o progresso da receita ativa."
        };
      case Section.MATERIAIS:
        return {
          title: "Recursos Materiais/Planilhas", // Exatamente como no Menu
          icon: <Package size={18}/>,
          desc: "Focado em Planilhas demonstrativas. Alterne entre os botões 'Tradicional', 'Ninho' ou 'Casadinho' para visualizar as tabelas. Veja os detalhes dos insumos utilizados na produção."
        };
      case Section.RH:
        return {
          title: "Recursos Humanos", // Exatamente como no Menu
          icon: <Briefcase size={18}/>,
          desc: "Gestão de Talentos. Navegue entre o 'Organograma' para visualizar a hierarquia e a aba 'Perfis da Equipe' para acessar biografias, contatos e habilidades individuais de cada colaborador."
        };
      case Section.FINANCEIRO:
        return {
          title: "Rec. Financeiros", // Exatamente como no Menu
          icon: <DollarSign size={18}/>,
          desc: "Inteligência Financeira. O painel destaca o Investimento Global Estrutural. Use as abas internas para decompor os dados em Gráficos de Pizza (Geral), Barras (RH) ou Listas (Patrimônio/Materiais)."
        };
      case Section.PATRIMONIO:
        return {
          title: "Rec. Patrimoniais", // Exatamente como no Menu
          icon: <ChefHat size={18}/>,
          desc: "Inventário de Ativos. Lista valorizada de todo o maquinário pesado (Fornos, Câmaras Frias). Essencial para entender o valor imobilizado e o plano de manutenção da confeitaria."
        };
      default:
        return {
          title: "Área de Trabalho",
          icon: <Info size={18}/>,
          desc: "Selecione um item no menu lateral para ver os detalhes aqui."
        };
    }
  };

  const dynamicInfo = getDynamicContent();

  if (!isOpen) return null;

  return (
    <div 
      ref={panelRef}
      className="fixed z-[100] flex flex-col w-[90vw] md:w-[500px] max-h-[85vh] rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.4)] overflow-hidden animate-in fade-in zoom-in-95 duration-200 bg-white dark:bg-[#1a1a1a] border-2 border-marsala-primary/40 backdrop-blur-xl"
      style={{ left: `${position.x}px`, top: `${position.y}px`, touchAction: 'none' }}
    >
        
        {/* Header Arrastável */}
        <div 
          className="drag-handle cursor-grab active:cursor-grabbing flex items-center justify-between p-4 bg-gradient-to-r from-marsala-primary to-marsala-secondary text-white select-none shadow-md touch-none"
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
        >
          <div className="flex items-center gap-2 pointer-events-none">
            <GripHorizontal size={24} className="opacity-80" />
            <h2 className="text-lg font-black flex items-center gap-2">
              <BookOpen size={20} /> Sobre o Software
            </h2>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); onClose(); }} 
            className="p-2 hover:bg-white/20 rounded-full transition-colors text-white cursor-pointer"
            onMouseDown={(e) => e.stopPropagation()}
            onTouchStart={(e) => e.stopPropagation()}
          >
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-black/20 shrink-0">
          <button 
            onClick={() => setActiveTab('about')}
            className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'about' ? 'bg-white dark:bg-[#1a1a1a] text-marsala-primary border-b-2 border-marsala-primary' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
          >
            Mapeamento (Numeração)
          </button>
          <button 
            onClick={() => setActiveTab('instructions')}
            className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'instructions' ? 'bg-white dark:bg-[#1a1a1a] text-marsala-primary border-b-2 border-marsala-primary' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'}`}
          >
            Ajuda Contextual
          </button>
        </div>

        {/* Content */}
        <div 
          className="flex-1 overflow-y-auto custom-scrollbar bg-white dark:bg-[#1a1a1a] p-6" 
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
        >
          {activeTab === 'instructions' ? (
            <div className="space-y-6 text-gray-700 dark:text-gray-300">
              <div className="space-y-3">
                <h3 className="font-bold text-xl text-marsala-primary dark:text-pink-200">Você está em: {dynamicInfo.title}</h3>
                <p className="leading-relaxed text-sm font-medium">
                  {dynamicInfo.desc}
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-800">
                   <h4 className="font-black text-blue-700 dark:text-blue-300 mb-2 text-sm flex items-center gap-2"><MousePointerClick size={16}/> O que fazer aqui?</h4>
                   <p className="text-xs leading-relaxed">Interaja com os elementos da tela. O sistema responde aos cliques nos gráficos, tabelas e cards de funcionários para revelar detalhes.</p>
                </div>
                <div className="bg-pink-50 dark:bg-pink-900/20 p-4 rounded-xl border border-pink-100 dark:border-pink-800">
                   <h4 className="font-black text-pink-700 dark:text-pink-300 mb-2 text-sm flex items-center gap-2"><Zap size={16}/> Dica da Giselle</h4>
                   <p className="text-xs leading-relaxed">Estou monitorando os dados de <strong>{dynamicInfo.title}</strong>. Experimente me perguntar sobre os valores mais altos ou discrepâncias.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
               <div className="bg-yellow-50 dark:bg-yellow-900/10 p-4 rounded-xl border border-yellow-200 dark:border-yellow-800 flex gap-3 items-center">
                  <div className="animate-bounce shrink-0">
                    <span className="w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center border-2 border-white dark:border-gray-800 shadow-sm text-sm">!</span>
                  </div>
                  <div>
                    <h4 className="font-black text-gray-800 dark:text-gray-200 text-sm">Legenda da Tela Atual</h4>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">
                      Confira abaixo o que significa cada número amarelo visível na sua tela agora.
                    </p>
                  </div>
               </div>

               <div className="space-y-4">
                  {/* Item 1 - Fixo */}
                  <div className="flex gap-4 p-3 rounded-2xl bg-gray-50 dark:bg-white/5 border border-transparent items-center">
                     <span className="shrink-0 w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-md border-2 border-white dark:border-gray-800 text-sm">1</span>
                     <div>
                        <h4 className="font-black text-gray-700 dark:text-gray-200 text-sm">Menu Lateral</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Navegação central entre os módulos do sistema.</p>
                     </div>
                  </div>

                  {/* Item 2 - Fixo */}
                  <div className="flex gap-4 p-3 rounded-2xl bg-gray-50 dark:bg-white/5 border border-transparent items-center">
                     <span className="shrink-0 w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-md border-2 border-white dark:border-gray-800 text-sm">2</span>
                     <div>
                        <h4 className="font-black text-gray-700 dark:text-gray-200 text-sm">Barra de Ferramentas</h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Acesso rápido ao Modo Escuro, Ajustes e Logout.</p>
                     </div>
                  </div>

                  {/* Item 3 - DINÂMICO E DESTACADO */}
                  <div className="flex gap-4 p-4 rounded-2xl bg-marsala-primary/10 border-2 border-marsala-primary/30 items-start relative overflow-hidden transition-all duration-300">
                     <div className="absolute right-0 top-0 p-8 bg-marsala-primary/5 rounded-bl-full -mr-4 -mt-4"></div>
                     <span className="shrink-0 z-10 w-10 h-10 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-lg border-2 border-white dark:border-gray-800 text-lg animate-pulse">3</span>
                     <div className="z-10">
                        <h4 className="font-black text-marsala-primary dark:text-pink-300 text-base flex items-center gap-2 mb-1">
                           {dynamicInfo.icon} {dynamicInfo.title}
                        </h4>
                        <p className="text-xs text-gray-700 dark:text-gray-300 font-bold leading-relaxed">
                           {dynamicInfo.desc}
                        </p>
                     </div>
                  </div>

                  {/* Item 4 - Fixo (Giselle Melhorada) */}
                  <div className="flex gap-4 p-3 rounded-2xl bg-gradient-to-r from-gray-50 to-pink-50 dark:from-white/5 dark:to-pink-900/10 border border-transparent items-start">
                     <span className="shrink-0 w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-md border-2 border-white dark:border-gray-800 text-sm mt-1">4</span>
                     <div className="w-full">
                        <h4 className="font-black text-gray-700 dark:text-gray-200 text-sm flex items-center gap-2">
                           Assistente Giselle <Sparkles size={12} className="text-yellow-500"/>
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 mb-2">
                           Sua analista de dados virtual. Ela lê a tela atual e tira dúvidas complexas.
                        </p>
                        
                        {/* Sugestões de Prompts */}
                        <div className="bg-white dark:bg-black/20 rounded-lg p-2.5 border border-gray-100 dark:border-white/5 space-y-2">
                           <p className="text-[10px] font-black uppercase text-marsala-primary dark:text-pink-300 tracking-widest mb-1">Experimente perguntar:</p>
                           <ul className="text-[11px] space-y-1.5 text-gray-600 dark:text-gray-300">
                              <li className="flex gap-2 items-center"><MessageSquare size={10} className="text-gray-400"/> "Qual o ingrediente mais caro da planilha?"</li>
                              <li className="flex gap-2 items-center"><MessageSquare size={10} className="text-gray-400"/> "Resuma os gastos de RH em uma frase."</li>
                              <li className="flex gap-2 items-center"><MessageSquare size={10} className="text-gray-400"/> "O rendimento do lote está dentro do esperado?"</li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
          )}
        </div>
    </div>
  );
};
