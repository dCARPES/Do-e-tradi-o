
import React from 'react';

export enum Section {
  DASHBOARD = 'dashboard',
  PATRIMONIO = 'patrimonio',
  MATERIAIS = 'materiais',
  RH = 'rh',
  FINANCEIRO = 'financeiro'
}

export interface User {
  username: string;
  isAuthenticated: boolean;
}

export interface NavItem {
  id: Section;
  label: string;
  icon: React.ElementType;
}
