
import { Section } from './types';
import { PieChart, ChefHat, Package, DollarSign, Users } from 'lucide-react';

export const APP_NAME = "Doce Tradição";

export const GISELLE_MESSAGES: Record<Section, string> = {
  [Section.DASHBOARD]: "Olá Edemar! 👩‍🍳 No painel geral você vê o coração da nossa produção. Como posso ajudar hoje?",
  [Section.PATRIMONIO]: "Equipamentos em dia significam produção sem paradas! Verifique o status dos fornos.",
  [Section.MATERIAIS]: "Controle cada grama para manter a margem. O granulado Melken é nosso item mais caro hoje.",
  [Section.RH]: "Nossa equipe cresceu! Veja como a estrutura está organizada no novo painel de Recursos Humanos.",
  [Section.FINANCEIRO]: "Atenção ao fluxo de caixa 💸. A folha de pagamento é nosso maior custo fixo.",
};

export const SALARIOS = {
  bryan: { 
    nome: "Bryan", 
    cargo: "Chefe (Dono)", 
    salario: 12000, 
    bio: "Fundador e visionário da Doce Tradição.", 
    skills: ["Gestão", "Estratégia", "Inovação"],
    email: "bryan_g_xavier@estudante.sesisenai.org.br",
    phone: "+55 47 9293-1804",
    gender: "male"
  },
  anielli: { 
    nome: "Anielli", 
    cargo: "Marketing", 
    salario: 4800, 
    bio: "Responsável pelo posicionamento da marca.", 
    skills: ["Social Media", "Ads", "Branding"],
    email: "anielli_xavier@estudante.sesisenai.org.br",
    phone: "+55 47 9670-2460",
    gender: "female"
  },
  emily: { 
    nome: "Emily", 
    cargo: "RH", 
    salario: 4200, 
    bio: "Gestão de pessoas e cultura organizacional.", 
    skills: ["Recrutamento", "Cultura", "Treinamento"],
    email: "emilly_silva151@estudante.sesisenai.org.br",
    phone: "+55 47 9708-2944",
    gender: "female"
  },
  felipe: { 
    nome: "Felipe", 
    cargo: "PCP", 
    salario: 4500, 
    bio: "Controle e planejamento da produção diária.", 
    skills: ["Logística", "Planejamento", "Estoque"],
    email: "felipe_s_muniz@estudante.sesisenai.org.br",
    phone: "+55 47 9122-4491",
    gender: "male"
  },
  edemar: { 
    nome: "Edemar", 
    cargo: "Líder de Produção", 
    salario: 5200, 
    bio: "Garante a qualidade final de cada doce.", 
    skills: ["Confeitaria", "Liderança", "Qualidade"],
    email: "edemar_pereira-ne@estudante.sesisenai.org.br",
    phone: "+55 47 9698-1042",
    gender: "male"
  },
  iasmin: { 
    nome: "Iasmin", 
    cargo: "Design Gráfico", 
    salario: 3200, 
    bio: "Identidade visual e materiais de pdv.", 
    skills: ["Photoshop", "Illustrator", "Layout"],
    email: "iasmin_camargo@estudante.sesisenai.org.br",
    phone: "+55 47 9727-0946",
    gender: "female"
  },
  jakelyne: { 
    nome: "Jakelyne", 
    cargo: "Auxiliar de RH", 
    salario: 2400, 
    bio: "Suporte administrativo e folha de pagamento.", 
    skills: ["Administrativo", "Organização"],
    email: "jakelyne_silva@estudante.sesisenai.org.br",
    phone: "+55 47 8823-1059",
    gender: "female"
  },
  luis: { 
    nome: "Luis", 
    cargo: "Assistente de PCP", 
    salario: 2800, 
    bio: "Apoio no controle de insumos e pedidos.", 
    skills: ["Excel", "Inventário"],
    email: "luis_silva156@estudante.sesisenai.org.br",
    phone: "+55 47 9742-0548",
    gender: "male"
  },
  barbara: { 
    nome: "Bárbara", 
    cargo: "Chefe de Cozinha", 
    salario: 3800, 
    bio: "Execução das receitas mestre tradicionais.", 
    skills: ["Alta Confeitaria", "Massas"],
    email: "barbara_moia@estudante.sesisenai.org.br",
    phone: "+55 47 8917-9327",
    gender: "female"
  },
  ana: { 
    nome: "Ana", 
    cargo: "Auxiliar de Cozinha", 
    salario: 2000, 
    bio: "Suporte na preparação e finalização.", 
    skills: ["Agilidade", "Boas Práticas"],
    email: "ana-carolina_gomes@estudante.sesisenai.org.br",
    phone: "+55 47 9727-3885",
    gender: "female"
  },
};

export const TOTAL_SALARIOS = Object.values(SALARIOS).reduce((acc, curr) => acc + curr.salario, 0);

export const NAV_ITEMS = [
  { id: Section.DASHBOARD, label: "Visão Geral", icon: PieChart },
  { id: Section.PATRIMONIO, label: "Rec. Patrimoniais", icon: ChefHat },
  { id: Section.MATERIAIS, label: "Recursos Materiais/Planilhas", icon: Package },
  { id: Section.RH, label: "Recursos Humanos", icon: Users },
  { id: Section.FINANCEIRO, label: "Rec. Financeiros", icon: DollarSign },
];
