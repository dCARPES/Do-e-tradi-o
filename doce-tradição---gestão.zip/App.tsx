
import React, { useState, useEffect } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { DashboardContent } from './components/Dashboard';
import { GisellePanel } from './components/GisellePanel';
import { SettingsModal } from './components/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { Section } from './types';
import { NAV_ITEMS } from './constants';
import { Moon, Sun, LogOut, Settings, Cookie, HelpCircle } from 'lucide-react';

// Componente Badge extraído para evitar recriação no render
// Z-index ajustado para 90 para ficar acima do conteúdo normal, mas abaixo do painel de ajuda (que é 100)
const TutorialBadge: React.FC<{ number: number; className?: string; visible: boolean }> = ({ number, className = '', visible }) => {
  if (!visible) return null;
  return (
    <div className={`absolute z-[90] w-8 h-8 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center shadow-[0_0_20px_rgba(250,204,21,0.8)] border-2 border-white dark:border-gray-800 animate-bounce ${className}`}>
      {number}
    </div>
  );
};

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [activeSection, setActiveSection] = useState<Section>(Section.DASHBOARD);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleLogin = (user: string) => {
    setUsername(user);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUsername('');
    setActiveSection(Section.DASHBOARD);
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-2 sm:p-4 overflow-hidden relative font-nunito">
       <div className="fixed inset-0 -z-10 bg-gradient-to-br from-marsala-soft to-pink-100 dark:from-dark-bg dark:to-black transition-colors duration-500"></div>
       
       <div className="glass-panel w-full max-w-7xl h-[95vh] rounded-[2rem] shadow-2xl overflow-hidden flex flex-col relative transition-colors duration-300">
          
          <header className="h-16 bg-marsala-primary dark:bg-dark-surface text-white px-6 flex items-center justify-between shadow-md shrink-0 z-10 border-b border-white/10 relative">
             <TutorialBadge number={2} visible={isHelpOpen} className="top-10 left-1/2 -translate-x-1/2" />
             
             <div className="flex items-center gap-3 font-bold text-lg">
                <Cookie className="animate-bounce-slow" />
                <span>Bem-vindo, <span className="font-pacifico text-xl font-normal ml-1 text-pink-100">{username}</span>!</span>
             </div>
             <div className="flex items-center gap-4 text-marsala-light/80">
                <button 
                  onClick={() => setIsHelpOpen(!isHelpOpen)}
                  className={`hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 ${isHelpOpen ? 'bg-yellow-400 text-black shadow-[0_0_15px_rgba(250,204,21,0.5)]' : ''}`}
                  title="Ajuda / Instruções"
                >
                  <HelpCircle size={20} />
                </button>
                <button 
                  onClick={() => setIsDarkMode(!isDarkMode)} 
                  className="hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                  title="Alternar Tema"
                >
                   {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
                </button>
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                >
                  <Settings size={20} />
                </button>
                <button 
                  onClick={handleLogout} 
                  className="hover:text-white transition-colors p-2 rounded-full hover:bg-white/10"
                >
                  <LogOut size={20} />
                </button>
             </div>
          </header>

          <div className="flex flex-1 overflow-hidden relative">
             <aside className="w-20 md:w-64 bg-white/50 dark:bg-zinc-900/50 backdrop-blur-sm border-r border-marsala-primary/10 dark:border-white/5 flex flex-col py-6 px-3 gap-2 shrink-0 transition-all duration-300 relative group z-20">
                <TutorialBadge number={1} visible={isHelpOpen} className="top-1 right-1" />
                
                {NAV_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-300 font-bold text-sm md:text-base ${
                      activeSection === item.id 
                        ? 'bg-marsala-primary text-white shadow-lg translate-x-1' 
                        : 'text-gray-600 dark:text-zinc-400 hover:bg-marsala-soft dark:hover:bg-zinc-800/50 hover:text-marsala-primary'
                    }`}
                  >
                    <item.icon size={22} className="shrink-0" />
                    <span className="hidden md:inline">{item.label}</span>
                  </button>
                ))}
             </aside>

             <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-white/30 dark:bg-black/20 scroll-smooth custom-scrollbar relative z-0">
                <DashboardContent activeSection={activeSection} showTutorial={isHelpOpen} />
             </main>
          </div>
       </div>

       <GisellePanel currentSection={activeSection} showTutorial={isHelpOpen} />

       <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
       <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} activeSection={activeSection} />
    </div>
  );
}
